﻿using Microsoft.Kinect;
using System;
using System.Windows.Shapes;

namespace KinectedPowerPoint.Toolbox
{
    public class Entry
    {
        public DateTime Time { get; set; }
        public Vector3 Position { get; set; }
    }
}
